# CSClubFall2016Project
A project created for the Computer Science Club. It will begin as a text based rpg, then will evolve using the same base classes into a larger project.

Language used: Java
Software Used: Netbeans

Project Lead: Zachary Kirchens |
Mentors: (None Currently) |
Designers: Zachary Kirchens |
Programmers: Zachary Kirchens |
Testers: (None Currently) |
